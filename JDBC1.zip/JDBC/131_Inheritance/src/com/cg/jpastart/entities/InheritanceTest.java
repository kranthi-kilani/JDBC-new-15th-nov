package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class InheritanceTest {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
	/*	
		//create one employee
		Employee employee = new Employee();
	
		employee.setName("Nanii");
		employee.setSalary(501);
		em.persist(employee);
	
		//create one manager
		Manager manager = new Manager();
	
		manager.setName("Priyaa");
		manager.setSalary(840);
		manager.setDepartmentName("SalesDept");
		em.persist(manager);*/
		//create concracter
		ContractEmployee ce=new ContractEmployee();
		ce.setName("chanu");
		ce.setSalary(70000);
		ce.setDuration(12);
		ce.setExtendable(true);
		em.persist(ce);
		
		em.getTransaction().commit();
		
		System.out.println("Added  to database.");
		em.close();
		factory.close();
	}
}
