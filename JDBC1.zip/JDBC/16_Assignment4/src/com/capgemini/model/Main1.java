package com.capgemini.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main1 {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Loan loan=new Loan();
		loan.setCustomerName("kranthi");
		loan.setLoanAmnt(2000);
		loan.setLoanId(100);
		
		Repayment repay1=new Repayment();
		repay1.setInsatllmentNo(1);
		repay1.setrAmnt(100);
		repay1.setRid(111);
		

		Repayment repay2=new Repayment();
		repay2.setInsatllmentNo(2);
		repay2.setrAmnt(200);
		repay2.setRid(222);
		

		loan.addRepayment(repay1);
		loan.addRepayment(repay2);
		
		em.persist(loan);
		System.out.println("added...");
		em.getTransaction().commit();
		em.close();
		emf.close();
		
	}

}
