package com.training.client;
 
/**
 * 
 * @author 
 *
 */
public class Test4 {

	int square(int n){
		/**
		 * @param n number to be computed for square
		 * @return return square of the number
		 */
		
		return n*n;
	}
}
