package com.capgemini.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Repay_master")
public class Repayment {
	@Id
	private int rid;
	private double rAmnt;
	private int insatllmentNo;
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public double getrAmnt() {
		return rAmnt;
	}
	public void setrAmnt(double rAmnt) {
		this.rAmnt = rAmnt;
	}
	public int getInsatllmentNo() {
		return insatllmentNo;
	}
	public void setInsatllmentNo(int insatllmentNo) {
		this.insatllmentNo = insatllmentNo;
	}
	@Override
	public String toString() {
		return "Repayment [rid=" + rid + ", rAmnt=" + rAmnt
				+ ", insatllmentNo=" + insatllmentNo + "]";
	}
	

}
