package com.capg.paymentwallet.bean;

import java.math.BigInteger;

public class ShowBalaneBean {
	
	
	private BigInteger phoneNum;
	
	public BigInteger getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(BigInteger phoneNum) {
		this.phoneNum = phoneNum;
	}

}
