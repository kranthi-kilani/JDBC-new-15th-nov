package com.training.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main1 {

	public static void main(String[] args) {
		String JPQL = "select p from Person p where p.salary>=:startRange and p.salary<=:endRange";
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Query query = em.createQuery(JPQL);
		query.setParameter("startRange", 15000.00);
		query.setParameter("endRange", 30000.00);
		List<Person> person = query.getResultList();
		for (Person p : person) {
			System.out.println(p.getPersonId() + " " + p.getName() + " "
					+ p.getSalary() + " " + p.getAge() + " " + p.getGender());
		}
			em.getTransaction().commit();
			em.close();
			emf.close();

		

	}

}
