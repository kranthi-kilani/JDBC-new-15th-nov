package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentToUppercase {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		String myQuery = "from Student";
		Query query = em.createQuery(myQuery);
		List<Student> studList = null;
		studList = query.getResultList();
		String str = null;
		for (Student stud : studList) {
			str = stud.getName().toUpperCase();
			stud.setName(str);
			System.out.println(str);
			em.getTransaction().begin();
			em.merge(stud);
			em.getTransaction().commit();
		}

		em.close();
		factory.close();

	}

}
