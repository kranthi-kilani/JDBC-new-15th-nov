package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Address address=em.find(Address.class, 1);
		System.out.println(address.getCity()+""+address.getStreet()+""+address.getState()+""+address.getZipCode()+""+address.getStudent().getName());
		/*Student student=em.find(Student.class, 1);
		System.out.println(student.getName()+""+student.getStudentId()+""+student.getAddress());*/
		em.getTransaction().commit();
		em.close();
		factory.close();
	
	factory = Persistence.createEntityManagerFactory("JPA-PU");
	em = factory.createEntityManager();
	em.getTransaction().begin();
	Student student=em.find(Student.class, 1);
	System.out.println(student.getName()+""+student.getAddress().getAddressId()+""+student.getStudentId()+""+student.getAddress().getCity()+""+student.getAddress().getZipCode()+""+student.getAddress().getStreet());
	em.getTransaction().commit();
	em.close();
	factory.close();

}
}
