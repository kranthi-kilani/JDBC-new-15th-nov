package com.training.client;

public @interface Id {

	
	
}
