package com.training.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub

				EntityManagerFactory emf = Persistence
						.createEntityManagerFactory("JPA-PU");
				EntityManager em = emf.createEntityManager();
				em.getTransaction().begin();
		      Query query=em.createNamedQuery("salaryFilterQuery");
		     
				query.setParameter("startRange", 15000.00);
				query.setParameter("endRange", 30000.00);
		      List<Person> person = query.getResultList();
				for (Person p : person) {
					System.out.println(p.getPersonId() + " " + p.getName() + " "
							+ p.getSalary() + " " + p.getAge() + " " + p.getGender());
				}
					em.getTransaction().commit();
					em.close();
					emf.close();

		      
	}

}
