package com.capgemini.entities;

import javax.persistence.Embeddable;
@Embeddable
public class Qualification {
	
	private String nameOfQualifi;
	private int experience;
	public String getNameOfQualifi() {
		return nameOfQualifi;
	}
	public void setNameOfQualifi(String nameOfQualifi) {
		this.nameOfQualifi = nameOfQualifi;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	@Override
	public String toString() {
		return "Qualification [nameOfQualifi=" + nameOfQualifi
				+ ", experience=" + experience + "]";
	}
	

}
